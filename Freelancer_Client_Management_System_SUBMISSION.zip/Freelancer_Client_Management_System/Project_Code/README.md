# FreelanceFlow – Freelancer Client Management System

Academic frontend prototype based on the supplied SRS.

## Technologies
- HTML5
- CSS3
- Vanilla JavaScript
- Browser Local Storage

## How to run
1. Extract the project folder.
2. Open `Project_Code/index.html` in Chrome, Firefox, Edge or another modern browser.
3. Use the sidebar to explore the dashboard, clients, projects, tasks, invoices, notifications and admin overview.

## Demonstrated features
- Client creation, listing, search and deletion
- Project creation, progress updates and deletion
- Task creation, status updates and deletion
- Invoice creation, status changes and deletion
- Dashboard summaries and notification feed
- Responsive layout for desktop and mobile

## Important scope note
This is a frontend academic prototype. Records are saved in the browser's Local Storage on the same device/browser. It does not implement production authentication, a server database, real email delivery or a real payment gateway. The admin page is a demonstration interface, not a secure admin system.
