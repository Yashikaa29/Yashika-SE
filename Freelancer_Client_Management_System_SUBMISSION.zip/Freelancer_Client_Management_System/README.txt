FREELANCER CLIENT MANAGEMENT SYSTEM – SUBMISSION PACKAGE

Contents:
1. Project_Code/ – HTML, CSS, JavaScript source code and README
2. Project_Presentation.pptx – project presentation
3. Github_Link.txt – paste your actual GitHub repository URL here

Run:
Open Project_Code/index.html in a modern browser.

Before submitting:
- Upload Project_Code contents to a public GitHub repository.
- Paste the real repository URL into Github_Link.txt.
- Keep the PPT and code inside this package.
- Compress this complete folder into a ZIP and upload it to POD.

This is an academic frontend prototype. It does not provide production authentication, real online payments, server-side storage or real email notifications.
